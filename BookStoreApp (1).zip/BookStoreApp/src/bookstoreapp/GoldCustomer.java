/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoreapp;

/**
 *
 * @author MARIA SAEED
 */
public class GoldCustomer extends Customer {
    
    private String password;
    private String username;
    private int points;

    public GoldCustomer(String username, String password, int points){
        this.username=username;
        this.password=password;
        this.points=points;
    }
    
    
    @Override
    public boolean login(String user, String pass){
        return user.equals(username)&&pass.equals(password);
    }

    @Override
    public boolean logout() {
        return true;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public int getPoints() {
       return points;
    }
    
}
