/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoreapp;

import java.io.File;
import java.io.IOException;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author MARIA SAEED
 */
public class Main extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        //The initial login screen:
        primaryStage.setTitle("Book Store Application");
        
        //sign in button
        Button loginButton = new Button();
        loginButton.setText("Login");
        
        //layout of screen
        GridPane loginGrid=new GridPane();
        loginGrid.setAlignment(Pos.CENTER);
        loginGrid.setHgap(10);
        loginGrid.setVgap(10);
        loginGrid.setPadding(new Insets(25, 25, 25, 25));
        
        //Adding text to screen
        Text scenetitle = new Text("Welcome to the BookStore App");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        loginGrid.add(scenetitle, 0, 0, 2, 1);
        
        //Username box
        Label userName = new Label("User Name:");
        loginGrid.add(userName, 0, 1);
        TextField userTextField = new TextField();
        loginGrid.add(userTextField, 1, 1);

        //Passowrd box
        Label pw = new Label("Password:");
        loginGrid.add(pw, 0, 2);
        PasswordField pwBox = new PasswordField();
        loginGrid.add(pwBox, 1, 2);
        
        //add button to loginGrid
        HBox hbButton = new HBox(10);
        hbButton.setAlignment(Pos.CENTER);
        hbButton.getChildren().add(loginButton);
        loginGrid.add(hbButton, 1, 4);
        
        Label invalid = new Label("Incorrect password or username");//in case of invalid login;
        
        Admin admin=new Admin();
        
        loginButton.setOnAction((ActionEvent e) -> {
            //getting customerlogininfo from textfile
            File dataFile=new File("customerList.txt");
            
            String username= userTextField.getText();//checking what is written in the fields by user
            String password= pwBox.getText();
            
            if(username.equals("admin") && password.equals("admin")){
                ownerLoginScreen(primaryStage, admin);
            }
            else{
                try{
                    if(admin.verification(username,password)){
                        customerScreen(primaryStage,admin);
                    }else
                        loginGrid.add(invalid,1,3);
                }catch(IOException e1){
                    loginGrid.add(invalid, 1, 3);
                }
            }
        });
           
        Scene loginScene=new Scene(loginGrid,500, 400);
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }

    public void ownerLoginScreen(Stage primaryStage, Admin admin){
        Admin owner;
        GridPane ownerGrid=new GridPane();
        
        //screen layout
        ownerGrid.setAlignment(Pos.CENTER);
        ownerGrid.setHgap(10);
        ownerGrid.setVgap(10);
        ownerGrid.setPadding(new Insets(25, 25, 25, 25));
        
        Text scenetitle = new Text("Welcome Admin");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        ownerGrid.add(scenetitle, 0, 0, 2, 1);

        //Books button
        Button booksButton = new Button();
        booksButton.setText("Books");
        
        //Customers button
        Button customersButton = new Button();
        customersButton.setText("Customers");
        
        //logout button
        Button logoutButton = new Button();
        logoutButton.setText("Logout");
        
        //add button to loginGrid
        VBox vbButton = new VBox(30);
        vbButton.setAlignment(Pos.TOP_CENTER);
        
        booksButton.setPrefWidth(500);
        booksButton.setPrefHeight(40);
        
        customersButton.setPrefWidth(500);
        customersButton.setPrefHeight(40);
        
        logoutButton.setPrefWidth(500);
        logoutButton.setPrefHeight(40);
        
        vbButton.getChildren().addAll(booksButton,customersButton,logoutButton);
        ownerGrid.add(vbButton, 0, 0);
        
        booksButton.setOnAction((ActionEvent e) -> {
            addBookScreen(primaryStage,admin);
        });
        
        customersButton.setOnAction((ActionEvent e) -> {
            addCustomerScreen(primaryStage,admin);
            //System.out.println("open customers screen");
        });
        
        logoutButton.setOnAction((ActionEvent e) -> {
            start(primaryStage);
            //System.out.println("return to login screen");
        });
        
        Scene scene = new Scene(ownerGrid, 500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public void addCustomerScreen(Stage primaryStage, Admin admin){
        GridPane addCustomerPane=new GridPane();
        
        ObservableList<Customer> data=FXCollections.observableArrayList();
        //Setting up the table
        TableView<Customer> table = new TableView<>();
        table.setEditable(true);
 
        TableColumn usernameCol=new TableColumn("Username");
        usernameCol.setMinWidth(100);
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
 
        TableColumn passwordCol=new TableColumn("Password");
        passwordCol.setMinWidth(100);
        passwordCol.setCellValueFactory(new PropertyValueFactory<>("password"));
 
        TableColumn pointsCol= new TableColumn("Points");
        pointsCol.setMinWidth(200);
        pointsCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        
        /*TextField addUsername=new TextField();
        addUsername.setPromptText("Username");
        addUsername.setMaxWidth(usernameCol.getPrefWidth());
        
        TextField addPassword=new TextField();
        addPassword.setPromptText("Password");
        addPassword.setMaxWidth(passwordCol.getPrefWidth());*/
        
       
        //This portion of the code will create a new customer file
        Label user=new Label("Username: ");
        TextField userField=new TextField();
        
        Label pass=new Label("Password: ");
        TextField passField=new TextField();
        
        Label addedText = new Label("Customer has been Added!");
        Label addedText1 = new Label("Customer has not been Added!");
        
        Button addButton=new Button("Add");
        addButton.setOnAction((ActionEvent e) -> {
            String username=userField.getText();
            String password=passField.getText();
            if(username!=null&&password!=null){
                admin.addCustomer(username,password);
                
                addCustomerPane.add(addedText, 1, 3);
            }else{
               addCustomerPane.add(addedText1, 1, 3); 
            }
        });
        
        Button backButton=new Button("Back");
        backButton.setOnAction((ActionEvent e) -> {
            ownerLoginScreen(primaryStage,admin);
        });
        
        addCustomerPane.setAlignment(Pos.CENTER);
        addCustomerPane.add(user, 0, 1);
        addCustomerPane.add(userField, 1, 1);
        addCustomerPane.add(pass, 0, 2);
        addCustomerPane.add(passField, 1, 2);
        addCustomerPane.add(addButton, 0,3);
        addCustomerPane.add(backButton, 0, 4);
        Scene scene = new Scene(addCustomerPane, 500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
        
        
        
        /* TableView<Customer> table = new TableView<>();
        table.setEditable(true);
 
        TableColumn usernameCol=new TableColumn("Username");
        usernameCol.setMinWidth(100);
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
 
        TableColumn passwordCol=new TableColumn("Password");
        passwordCol.setMinWidth(100);
        passwordCol.setCellValueFactory(new PropertyValueFactory<>("password"));
 
        TableColumn pointsCol= new TableColumn("Points");
        pointsCol.setMinWidth(200);
        pointsCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        
        TextField addUsername=new TextField();
        addUsername.setPromptText("Username");
        addUsername.setMaxWidth(usernameCol.getPrefWidth());
        
        TextField addPassword=new TextField();
        addPassword.setPromptText("Password");
        addPassword.setMaxWidth(passwordCol.getPrefWidth());/*
      
        
        
        
        
        /*GridPane addCustomerGrid=new GridPane();
        addCustomerGrid.setAlignment(Pos.CENTER);
        addCustomerGrid.setHgap(2);
        addCustomerGrid.setVgap(5);
        addCustomerGrid.setPadding(new Insets(5, 5, 5, 5));
        
        TableView customerTable = new TableView();
        customerTable.setEditable(true);
        TableColumn username=new TableColumn("Username");
        username.setCellValueFactory(new PropertyValueFactory<>("Username"));
        TableColumn password=new TableColumn("Password");
        password.setCellValueFactory(new PropertyValueFactory<>("Password"));
        TableColumn points=new TableColumn("Points");
        points.setCellValueFactory(new PropertyValueFactory<>("Points"));

        customerTable.getColumns().addAll(username,password,points);*/
        
        /*VBox tableBox=new VBox();
        tableBox.setSpacing(10);
        tableBox.setPadding(new Insets(10, 0, 0, 10));
        tableBox.getChildren().addAll(customerTable); 
        addCustomerGrid.add(tableBox,0,1);*/
        
        
        /*
        //Adding buttons and labels to the 2nd pane (do not work)
        VBox labels=new VBox(5);
        labels.setAlignment(Pos.BASELINE_CENTER);

        HBox un=new HBox();
        Label userName = new Label("User Name:");
        TextField userTextField = new TextField();
        un.getChildren().addAll(userName,userTextField);
        
        HBox pws=new HBox();
        Label pw = new Label("Password:");
        PasswordField pwBox = new PasswordField();
        pws.getChildren().addAll(pw,pwBox);
        
        Button addButton=new Button();
        addButton.setText("Add");
        addButton.setOnAction((ActionEvent e) -> {
            System.out.println("add button pressed");
        });
        
        labels.getChildren().addAll(un,pws);
        addCustomerGrid.add(labels, 0, 2);
        
        //Adding buttons to the 3rd pane
        Button backButton=new Button();
        backButton.setText("Back");
        backButton.setOnAction((ActionEvent e) -> {
            ownerLoginScreen(primaryStage,admin);
            //System.out.println("return to login screen");
        });
        
        Button deleteButton=new Button();
        deleteButton.setText("Delete");
        deleteButton.setOnAction((ActionEvent e) -> {
            System.out.println("deletebutton pressed");
        });
        
        HBox hbButton = new HBox(10);
        hbButton.setAlignment(Pos.CENTER);
        hbButton.getChildren().addAll(backButton,deleteButton);
        addCustomerGrid.add(hbButton,0,3);*/
        
        /*
        
        Scene scene=new Scene(table,500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();/*
        
        /* GridPane addCustomerGrid=new GridPane();
        
        //screen layout
        addCustomerGrid.setAlignment(Pos.CENTER);
        addCustomerGrid.setHgap(10);
        addCustomerGrid.setVgap(10);
        addCustomerGrid.setPadding(new Insets(25, 25, 25, 25));
        
        //random text
        Text scenetitle = new Text("add cutomer screen");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        addCustomerGrid.add(scenetitle, 0, 0, 2, 1);
        
        Scene scene=new Scene(addCustomerGrid,500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();*/
    }
    
    public void addBookScreen(Stage primaryStage, Admin admin){
        GridPane addBookGrid=new GridPane();
        
        //screen layout
        addBookGrid.setAlignment(Pos.CENTER);
        addBookGrid.setHgap(10);
        addBookGrid.setVgap(10);
        addBookGrid.setPadding(new Insets(25, 25, 25, 25));
        
        //random text
        Text scenetitle = new Text("add book screen");
        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        addBookGrid.add(scenetitle, 0, 0, 2, 1);
        
        Scene scene=new Scene(addBookGrid,500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public void customerScreen(Stage primaryStage, Admin admin){
        GridPane customerGrid=new GridPane();
        
        //screen layout
        customerGrid.setAlignment(Pos.CENTER);
        customerGrid.setHgap(10);
        customerGrid.setVgap(10);
        customerGrid.setPadding(new Insets(25, 25, 25, 25));
       
        //title of scene
        Text sceneTitle = new Text("Welcome  " + admin.getCustomerUserName());
        sceneTitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));

        //Text that shows on the screen
        Label numPoints=new Label("You have "+admin.getPoints()+" points");
        Label status=new Label("You are a "+admin.getStatus()+" customer");
        
        VBox labels=new VBox(5);
        labels.setAlignment(Pos.CENTER);
        labels.getChildren().addAll(sceneTitle,numPoints,status);
        customerGrid.add(labels, 0, 1);
        
        //buttons 
        Button buyButton=new Button();//buy the books with this button
        buyButton.setText("Buy");
        
        Button buyWithPointsButton=new Button();
        buyWithPointsButton.setText("Redeem Points & Buy");
        
        Button logoutButton=new Button();
        logoutButton.setText("Logout");
        logoutButton.setOnAction((ActionEvent e) -> {
            start(primaryStage);
            //System.out.println("return to login screen");
        });
        
        HBox hbButton = new HBox(10);
        hbButton.setAlignment(Pos.CENTER);
        hbButton.getChildren().addAll(buyButton,buyWithPointsButton,logoutButton);
        customerGrid.add(hbButton, 0, 3);

        Scene scene = new Scene(customerGrid, 500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
       /* public void customerCostScreen(Stage primaryStage, Admin admin){
        GridPane customerCostGrid=new GridPane();
        
        //screen layout
        customerCostGrid.setAlignment(Pos.CENTER);
        customerCostGrid.setHgap(10);
        customerCostGrid.setVgap(10);
        customerCostGrid.setPadding(new Insets(25, 25, 25, 25));

        //Text that shows on the screen
        Label totalCost=new Label("Total= $"+admin.getPoints()+" points");
        Label status=new Label("You are a "+admin.getStatus()+" cusomer");
        
        VBox labels=new VBox(5);
        labels.setAlignment(Pos.CENTER);
        labels.getChildren().addAll(sceneTitle,numPoints,status);
        customerCostGrid.add(labels, 0, 1);
        
        //buttons 
        Button buyButton=new Button();//buy the books with this button
        buyButton.setText("Buy");
        
        Button buyWithPointsButton=new Button();
        buyWithPointsButton.setText("Redeem Points & Buy");
        
        Button logoutButton=new Button();
        logoutButton.setText("Logout");
        logoutButton.setOnAction((ActionEvent e) -> {
            start(primaryStage);
            //System.out.println("return to login screen");
        });
        
        HBox hbButton = new HBox(10);
        hbButton.setAlignment(Pos.CENTER);
        hbButton.getChildren().addAll(buyButton,buyWithPointsButton,logoutButton);
        customerCostGrid.add(hbButton, 0, 3);

        Scene scene = new Scene(customerCostGrid, 500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
        }*/
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
