/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoreapp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

/**
 *
 * @author MARIA SAEED
 */
public class Admin {
    
    private String password;
    private String username;
    private int points;
    private Customer temp;
    public ArrayList<String> customerUsernames=new ArrayList<>();
    
    public boolean verification(String user, String pass) throws IOException{
        boolean verification=false;
        try{
            BufferedReader input= new BufferedReader(new FileReader(user+"customerInformation.txt"));
            String info= input.readLine();
            String customerInfo[]=info.split(",");
            username=customerInfo[0];
            password=customerInfo[1];
            points=Integer.parseInt(customerInfo[2]);//current balance
            
            Customer customer;
            
            if(points<1000){
                customer=new SilverCustomer(username,password,points);
                if(customer.login(user,pass)){
                    temp=customer;
                    verification=true;
                }
            }
            else if(points>=100){
                customer=new GoldCustomer(username,password,points);
                if(customer.login(user,pass)){
                    temp=customer;
                    verification=true;
                }
            }
        }catch(FileNotFoundException e1){
            System.out.println("file does not exist");
        }
        
        return verification;
    }
    
    //method that adds a new file for a new customer
    public void addCustomer(String username, String password){

        File customerFile=new File(username+"customerInformation.txt");
        try{
            FileWriter writingCustomerToFile=new FileWriter(customerFile);
            try (BufferedWriter writer=new BufferedWriter(writingCustomerToFile)) {
                writer.write(username+ ","+password+ ","+0);
                customerUsernames.add(username);
            }
        }catch(IOException e){
            System.out.println("could not add customer");
        }
        
    }

    public ArrayList<String> getCustomerUsernames() {
        return customerUsernames;
    }
    
    
    
    public String getCustomerUserName(){
        return temp.getUsername();
    }
    
    public int getPoints(){
        return temp.getPoints();
    }
    
    public String getStatus(){
        if(temp instanceof SilverCustomer)
            return "SILVER";
        else
            return "GOLD";
    }
    
}
